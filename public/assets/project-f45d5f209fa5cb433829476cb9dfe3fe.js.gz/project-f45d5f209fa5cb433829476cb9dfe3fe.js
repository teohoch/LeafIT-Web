jQuery(document).on("ready page:change", function() {

    /*
     Countdown initializer
     */
    var now = new Date().valueOf();
    var date = new Date(2014,10,14).valueOf()
    var countTo = date
    $('.timer').countdown(countTo, function(event) {
        var $this = $(this);
        switch(event.type) {
            case "seconds":
            case "minutes":
            case "hours":
            case "days":
            case "weeks":
            case "daysLeft":
                $this.find('span.'+event.type).html(event.value);
                break;
            case "finished":
                $this.hide();
                break;
        }
    });

});
