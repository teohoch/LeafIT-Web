jQuery(document).on("ready page:change", function() {

    /*
     Background slideshow
     */
    $('.team').backstretch([
        "/assets/team/equipo.jpg",

    ], {duration: 3000, fade: 750});


});

